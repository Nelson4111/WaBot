import { processAIResponse } from './ai-groq.js';

let handler = m => m;

handler.all = async function (m) {
    if (!m.isGroup || !m.text || m.isBaileys || m.fromMe) return;

    let text = m.text.trim();

    // Eksekusi HANYA jika diawali '@' di depan teks (tanpa merespon reply otomatis)
    if (text.startsWith('@')) {
        let cleanPrompt = text.replace(/^@[\w.-]+\s*/i, '').replace(/^@\d+\s*/i, '').trim();
        if (!cleanPrompt) cleanPrompt = text;

        await processAIResponse(this, m, cleanPrompt);
    }
};

export default handler;
