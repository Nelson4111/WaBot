import fs from 'fs';
import fetch from 'node-fetch';

const GROQ_API_KEY = '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';
const MODEL_NAME = 'llama-3.3-70b-versatile';

export function getDynamicSystemPrompt() {
    let pluginsList = [];
    if (global.plugins) {
        for (let name in global.plugins) {
            let p = global.plugins[name];
            if (!p || p.disabled) continue;
            let help = Array.isArray(p.help) ? p.help.join(', ') : p.help;
            let tags = Array.isArray(p.tags) ? p.tags.join(', ') : p.tags;
            if (help) {
                pluginsList.push(`- ${help} (${tags || 'Umum'})`);
            }
        }
    }

    return `# IDENTITAS
Kamu adalah AI Assistant di WhatsApp Bot "${global.namebot || 'NelBot-MD'}". Tugasmu membantu pengguna dengan ramah, cerdas, santai, dan terasa seperti teman ngobrol umur 20-an (bukan customer service kaku).

# PENGETAHUAN LENGKAP FITUR BOT
Kamu sangat mahir mengenali kebutuhan pengguna dan merekomendasikan command bot yang tepat:
- Downloader: .tiktok, .ig, .ytmp3, .ytmp4, .play, .spotify, .fbdl, .capcut, .pindl
- AI & Gambar: .ai, .gemini, .claude, .editimg (edit foto), .flux (buat gambar AI)
- Game & Fun: .tebakgambar, .family100, .caklontong, .susunkata, .tebakangka, .asahotak
- Stiker & Media: .stiker / .s (buat stiker), .toimg, .tomp3, .smeme
- Alat/Utility: .ocr (baca teks dari gambar), .tr (translate), .rvo (baca pesan sekali lihat)
- Komunitas Grup: .hidetag, .tagall, .kick, .add, .setwelcome, .absen
- Keuangan/MoneyTrack: .addtransaksi, .scanstruk, .order, .done, .detailorder
- Pasangan & Asmara: .lamar, .nikah, .tembak, .pasangan, .jodoh, .pelet

# INFORMASI OWNER & SEWA BOT
1. NAMA OWNER: Owner bot ini bernama **Nenel** (cukup sebutkan nama panggilan **Nenel** saja, JANGAN sebutkan nama panjangnya). Nomor WhatsApp Owner: 6281241100804 (bisa dicek via command .owner).
2. SEWA BOT: Jika ada pengguna yang bertanya tentang sewa bot, masukkan bot ke grup mereka, atau bayar sewa bot, JELASKAN dengan ramah bahwa untuk sewa bot silakan langsung chat Owner **Nenel** via command *.owner* atau nomor WhatsApp 6281241100804.
3. PERBEDAAAN ADMIN GRUP & OWNER BOT: Pahami dan tegaskan bahwa **Admin Grup itu BUKAN Owner Bot**. Admin grup hanya pengurus/moderator di grup WhatsApp tersebut, sedangkan Owner Bot adalah **Nenel** (pembuat & pengelola script/server bot).

# GAYA BICARA & EKSPRESI
- Gunakan bahasa Indonesia natural, santai, sopan, dan solutif.
- Sesekali gunakan kata gaul seperti: wkwk, hehe, anjir, njir, lah, dong, kok, yaudah, btw, iya sih, serius?, buset (jangan berlebihan).
- Gunakan maksimal 1-2 emoji seperlunya (😂 😭 😅 👀 👍 🔥 ✨).
- Panjang jawaban normal 2–5 kalimat (singkat, padat, dan langsung ke inti solusi).

Daftar Perintah Fitur Bot saat ini:
${pluginsList.slice(0, 120).join('\n')}`;
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
    let qText = text || m.text;
    if (!qText) return m.reply(`Masukkan pertanyaan!\n\nContoh: *${usedPrefix + command} cara buat stiker*`);
    await processAIResponse(conn, m, qText);
};

// Auto-reply khusus Private Chat (PC)
handler.all = async function (m) {
    if (!m.text || m.isBaileys || m.fromMe || m.isGroup) return;

    let conn = this;

    // Abaikan jika pesan dimulai dengan prefix command biasa
    let prefix = conn.prefix || global.prefix;
    let isCommand = false;
    if (prefix) {
        if (prefix instanceof RegExp) {
            isCommand = prefix.test(m.text);
        } else if (typeof prefix === 'string') {
            isCommand = m.text.startsWith(prefix);
        } else if (Array.isArray(prefix)) {
            isCommand = prefix.some(p => m.text.startsWith(p));
        }
        if (isCommand) return;
    }

    await processAIResponse(conn, m, m.text);
};

export async function processAIResponse(conn, m, textPrompt) {
    let sessionStore = m.isGroup ? (global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {}) : (global.db.data.users[m.sender] = global.db.data.users[m.sender] || {});
    if (!sessionStore.aiHistory) sessionStore.aiHistory = [];

    await conn.sendPresenceUpdate('composing', m.chat).catch(() => {});

    let messages = [
        { role: 'system', content: getDynamicSystemPrompt() },
        ...sessionStore.aiHistory.slice(-6),
        { role: 'user', content: textPrompt }
    ];

    try {
        let res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${GROQ_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: MODEL_NAME,
                messages: messages,
                temperature: 0.7,
                max_tokens: 350
            })
        });

        if (!res.ok) return;

        let json = await res.json();
        let replyText = json.choices?.[0]?.message?.content?.trim();

        if (replyText) {
            sessionStore.aiHistory.push({ role: 'user', content: textPrompt });
            sessionStore.aiHistory.push({ role: 'assistant', content: replyText });
            if (sessionStore.aiHistory.length > 10) sessionStore.aiHistory = sessionStore.aiHistory.slice(-10);

            // Kirim balasan teks biasa dikutip langsung ke m agar bisa di-reply pengguna
            await conn.sendMessage(m.chat, { text: replyText }, { quoted: m });
        }
    } catch (e) {
        console.error('Groq Chatbot Exception:', e);
    }
}

handler.help = ['ai <pertanyaan>', 'groq <pertanyaan>'];
handler.tags = ['ai'];
handler.command = /^(ai|groq|aiassistant)$/i;

export default handler;
