/**
 * Plugin Broadcast dengan konfirmasi BUTTON
 * .bc    = broadcast ke semua private chat
 * .bcgc  = broadcast ke semua grup
 * .bcall = broadcast ke semua (private + grup)
 * Akses: Owner ATAU (Admin Grup + Premium)
 */

if (!global.bcSessions) global.bcSessions = {}

// ─── Fungsi kirim button konfirmasi ──────────────────────────────────────────
async function sendBcButton(conn, chatId, quotedMsg, sessionId, preview, targetCount, typeLabel) {
  const text =
    `╭──『 *⚠️ KONFIRMASI BROADCAST* 』\n` +
    `│\n` +
    `│ 📋 *Target:* ${typeLabel}\n` +
    `│ 👥 *Jumlah:* ${targetCount} target\n` +
    `│ ⏱️ *Estimasi:* ~${Math.ceil(targetCount * 3 / 60)} menit\n` +
    `│\n` +
    `│ 📝 *Preview Pesan:*\n` +
    `│ ${preview.replace(/\n/g, '\n│ ')}\n` +
    `│\n` +
    `│ Tekan tombol di bawah untuk\n` +
    `│ konfirmasi pengiriman!\n` +
    `╰─────────────────────`

  const buttons = [
    {
      buttonId: `bc_confirm_${sessionId}`,
      buttonText: { displayText: '✅ Ya, Kirim Sekarang' },
      type: 1
    },
    {
      buttonId: `bc_cancel_${sessionId}`,
      buttonText: { displayText: '❌ Batal, Jangan Kirim' },
      type: 1
    }
  ]

  return await conn.sendMessage(chatId, {
    text,
    buttons,
    headerType: 1,
    footer: '⏰ Berlaku 5 menit'
  }, { quoted: quotedMsg })
}

// ─── Fungsi eksekusi broadcast ────────────────────────────────────────────────
async function executeBroadcast(conn, session) {
  const { targetIds, content, hasMedia, mime, quotedMsg, chat, type } = session

  const typeLabel = type === 'gc' ? 'grup' : type === 'pc' ? 'user' : 'semua'

  await conn.sendMessage(chat, {
    text:
      `🚀 *Broadcast Dimulai!*\n` +
      `📋 Target: *${targetIds.length}* ${typeLabel}\n` +
      `⏳ Harap tunggu...`
  })

  let sukses = 0
  let gagal = 0

  const fakeQuoted = {
    key: {
      fromMe: false,
      participant: '0@s.whatsapp.net',
      remoteJid: 'status@broadcast'
    },
    message: { conversation: global.namebot || 'NelBot-MD' }
  }

  for (const id of targetIds) {
    try {
      await new Promise(resolve => setTimeout(resolve, 3000)) // delay 3 detik

      if (hasMedia && quotedMsg) {
        const media = await quotedMsg.download?.().catch(() => null)
        if (media) {
          const msgContent = mime?.includes('image')
            ? { image: media, caption: content || '' }
            : { video: media, caption: content || '' }
          await conn.sendMessage(id, msgContent, { quoted: fakeQuoted })
        } else {
          await conn.sendMessage(id, { text: content || '(pesan)' }, { quoted: fakeQuoted })
        }
      } else {
        await conn.sendMessage(id, { text: content || '(pesan)' }, { quoted: fakeQuoted })
      }

      sukses++
    } catch {
      gagal++
    }
  }

  await conn.sendMessage(chat, {
    text:
      `✅ *Broadcast Selesai!*\n\n` +
      `📊 *Laporan:*\n` +
      `┌ ✅ Berhasil : *${sukses}*\n` +
      `└ ❌ Gagal    : *${gagal}*\n` +
      `━━━━━━━━━━━━━━━\n` +
      `📋 Total      : *${targetIds.length}*`
  })
}

// ─── HANDLER UTAMA ────────────────────────────────────────────────────────────
const handler = async (m, { conn, text, quoted, mime, usedPrefix, command }) => {
  const content = text?.trim() || quoted?.text?.trim() || null

  if (!content && !quoted) {
    return m.reply(
      `╭──『 *📢 BROADCAST NelBot-MD* 』\n` +
      `│\n` +
      `│ *Cara Pakai:*\n` +
      `│ *${usedPrefix}bc* <teks>   → BC ke semua private\n` +
      `│ *${usedPrefix}bcgc* <teks> → BC ke semua grup\n` +
      `│ *${usedPrefix}bcall* <teks> → BC ke semua (private+grup)\n` +
      `│\n` +
      `│ 💡 Bisa reply gambar/video + caption\n` +
      `│ untuk broadcast media sekaligus.\n` +
      `╰─────────────────────`
    )
  }

  const isGc = /^bcgc$/i.test(command)
  const isAll = /^bcall$/i.test(command)

  // ── Kumpulkan target ──────────────────────────────────────────────
  let targetIds = []
  const botJid = conn.decodeJid(conn.user.id)

  if (isAll) {
    // Gabungan private + grup
    const users = global.db.data?.users || {}
    const pcIds = Object.keys(users).filter(j => j.endsWith('@s.whatsapp.net') && j !== botJid)
    const groups = await conn.groupFetchAllParticipating().catch(() => ({}))
    const gcIds = Object.keys(groups)
    targetIds = [...new Set([...pcIds, ...gcIds])]
  } else if (isGc) {
    const groups = await conn.groupFetchAllParticipating().catch(() => ({}))
    targetIds = Object.keys(groups)
  } else {
    const users = global.db.data?.users || {}
    targetIds = Object.keys(users).filter(j => j.endsWith('@s.whatsapp.net') && j !== botJid)
  }

  if (targetIds.length === 0) {
    return m.reply(`❌ Tidak ada target yang ditemukan.`)
  }

  const typeLabel = isAll
    ? '🌐 Semua (Private + Grup)'
    : isGc ? '🏘️ Semua Grup' : '👤 Semua Private Chat'

  const preview = content
    ? (content.length > 100 ? content.substring(0, 100) + '...' : content)
    : '🖼️ [Media]'

  // ── Simpan session ────────────────────────────────────────────────
  const sessionId = `${m.sender.replace('@s.whatsapp.net', '')}_${Date.now()}`

  global.bcSessions[sessionId] = {
    type: isAll ? 'all' : isGc ? 'gc' : 'pc',
    targetIds,
    content,
    hasMedia: !!(quoted && mime && (mime.includes('image') || mime.includes('video'))),
    mime: mime || '',
    quotedMsg: quoted || null,
    sender: m.sender,
    chat: m.chat,
    time: Date.now(),
    status: 'pending'
  }

  // Auto hapus session setelah 5 menit
  setTimeout(() => {
    if (global.bcSessions[sessionId]?.status === 'pending') {
      delete global.bcSessions[sessionId]
    }
  }, 5 * 60 * 1000)

  // ── Kirim button konfirmasi ───────────────────────────────────────
  await sendBcButton(conn, m.chat, m, sessionId, preview, targetIds.length, typeLabel)
}

// ─── Tangkap klik button (buttonsResponseMessage) ────────────────────────────
handler.all = async function (m) {
  try {
    // Cek buttonsResponseMessage (tombol biasa)
    const btnResp = m.message?.buttonsResponseMessage
    if (!btnResp) return

    const buttonId = btnResp.selectedButtonId || ''
    if (!buttonId.startsWith('bc_confirm_') && !buttonId.startsWith('bc_cancel_')) return

    // Ekstrak session ID
    const sessionId = buttonId.replace(/^bc_(confirm|cancel)_/, '')
    const session = global.bcSessions[sessionId]
    if (!session || session.status !== 'pending') return

    // Pastikan hanya pengirim perintah yang bisa konfirmasi
    const responder = this.decodeJid(m.key.participant || m.key.remoteJid)
    if (responder !== session.sender) return

    session.status = 'processing'

    if (buttonId.startsWith('bc_cancel_')) {
      delete global.bcSessions[sessionId]
      return await this.sendMessage(session.chat, {
        text: `❌ *Broadcast Dibatalkan!*\nPesan tidak jadi dikirim. Aman! 😄`
      })
    }

    if (buttonId.startsWith('bc_confirm_')) {
      await executeBroadcast(this, session)
      delete global.bcSessions[sessionId]
    }

  } catch (e) {
    console.error('[BC Button Handler]', e)
  }
}

handler.help = ['bc <pesan>', 'bcgc <pesan>', 'bcall <pesan>']
handler.tags = ['owner']
handler.command = /^(bc|bcgc|bcall)$/i

// Cek akses: owner ATAU (admin grup + premium)
handler.before = async function (m, { isOwner, isAdmin, isPrems }) {
  if (!m.text) return false
  const cmd = m.text.trim().toLowerCase().split(/\s+/)[0].replace(/^[^a-z]+/, '')
  if (!/^(bc|bcgc|bcall)$/.test(cmd)) return false

  if (isOwner) return false
  if (isAdmin && isPrems) return false

  if (isPrems && !isAdmin) {
    m.reply(`❌ Fitur ini hanya untuk *Owner* atau *Admin Grup + Premium*.`)
    return true
  }
  if (isAdmin && !isPrems) {
    m.reply(`❌ Fitur ini membutuhkan status *Premium* untuk Admin Grup.`)
    return true
  }

  m.reply(`❌ Kamu tidak punya akses ke fitur ini.`)
  return true
}

export default handler
