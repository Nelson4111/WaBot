'use strict';

/**
 * index.js — Entry point utama aplikasi Minecraft Bot.
 *
 * File ini sengaja dibuat sesederhana mungkin.
 * Semua logika ada di dalam src/core/BotManager.js dan modul-modul lainnya.
 *
 * Tanggung jawab:
 * 1. Handle uncaught exceptions dan unhandled promise rejections
 * 2. Inisialisasi DataService (buat folder dan file default)
 * 3. Start BotManager
 * 4. Start Web Dashboard
 * 5. Start Services (StatsService, HealthCheck)
 * 6. Handle SIGINT/SIGTERM untuk graceful shutdown
 */

// Load config sebelum semua modul lain — ini juga load dotenv
const config = require('./src/config');
const { logger, createModuleLogger } = require('./src/utils/logger');

const log = createModuleLogger('App');

// ── Catch global errors ───────────────────────────────────────────────────────

process.on('uncaughtException', (err) => {
  logger.error(`[App] Uncaught Exception: ${err.message}`, { stack: err.stack });
  // Jangan langsung exit — biarkan reconnect logic bekerja
  // Tapi jika error sangat fatal (mis. port sudah dipakai), mungkin perlu exit
});

process.on('unhandledRejection', (reason) => {
  const msg = reason instanceof Error ? reason.message : String(reason);
  logger.warn(`[App] Unhandled Rejection: ${msg}`);
});

// ── Bootstrap ─────────────────────────────────────────────────────────────────

async function main() {
  log.info('========================================');
  log.info('   Minecraft AFK Bot v1.0.0');
  log.info(`   Env: ${config.env.nodeEnv}`);
  log.info(`   Server: ${config.env.serverHost}:${config.env.serverPort}`);
  log.info(`   Bot: ${config.env.botUsername}`);
  log.info('========================================');

  // Step 1: Inisialisasi folder dan file data
  const DataService = require('./src/services/DataService');
  await DataService.initDataDir();
  log.info('DataService: folder dan file data siap');

  // Step 2: Buat dan start BotManager
  const BotManager = require('./src/core/BotManager');
  const botManager = new BotManager();

  // Step 3: Buat StatsService dan HealthCheck (inject botManager)
  const StatsService = require('./src/services/StatsService');
  const HealthCheck = require('./src/services/HealthCheck');

  const statsService = new StatsService(botManager);
  const healthCheck = new HealthCheck(botManager);

  statsService.start();
  healthCheck.start();

  // Step 4: Start Web Dashboard (jika diaktifkan)
  if (config.env.webEnabled) {
    const { startWebServer } = require('./src/web/server');
    startWebServer(botManager, statsService);
  } else {
    log.info('Web Dashboard dinonaktifkan (mode log-only untuk VPS/Panel)');
  }

  // Step 5: Start bot (connect ke server Minecraft)
  botManager.start();

  // ── Graceful Shutdown ─────────────────────────────────────────────────────
  function shutdown(signal) {
    log.warn(`\nMenerima signal ${signal}. Menghentikan bot dengan graceful...`);

    statsService.stop();
    healthCheck.stop();
    botManager.stop();

    log.info('Bot dihentikan. Sampai jumpa!');
    process.exit(0);
  }

  process.on('SIGINT', () => shutdown('SIGINT'));   // Ctrl+C
  process.on('SIGTERM', () => shutdown('SIGTERM')); // pm2 stop / systemctl stop
}

// Jalankan aplikasi
main().catch((err) => {
  logger.error(`Fatal error saat startup: ${err.message}`, { stack: err.stack });
  process.exit(1);
});
