'use strict';

const Joi = require('joi');

// ── Schema Validasi Config ──────────────────────────────────────────────────

/**
 * Schema validasi menggunakan Joi.
 * Jika ada field yang salah tipe atau hilang, akan throw error yang jelas
 * sehingga tidak ada crash misterius karena typo di config.json.
 */
const configSchema = Joi.object({
  bot: Joi.object({
    version: Joi.string().required(),
    viewDistance: Joi.string()
      .valid('far', 'normal', 'short', 'tiny')
      .default('tiny'),
    chatLengthLimit: Joi.number().integer().min(1).max(256).default(256),
    physicsEnabled: Joi.boolean().default(true),
  }).required(),

  reconnect: Joi.object({
    enabled: Joi.boolean().default(true),
    initialDelayMs: Joi.number().integer().min(1000).default(5000),
    maxDelayMs: Joi.number().integer().min(5000).default(300000),
    multiplier: Joi.number().min(1).max(10).default(2),
  }).required(),

  auth: Joi.object({
    loginTriggerWords: Joi.array().items(Joi.string()).min(1).required(),
    loginDelayMs: Joi.number().integer().min(0).default(1500),
    loginTimeoutMs: Joi.number().integer().min(5000).default(30000),
  }).required(),

  antiAfk: Joi.object({
    enabled: Joi.boolean().default(true),
    intervalSeconds: Joi.number().integer().min(5).max(300).default(30),
    actions: Joi.array()
      .items(Joi.string().valid('look', 'sneak', 'walk'))
      .default(['look', 'sneak', 'walk']),
  }).required(),

  guard: Joi.object({
    enabled: Joi.boolean().default(false),
    radius: Joi.number().integer().min(1).max(64).default(16),
    attackInterval: Joi.number().integer().min(100).default(500),
    hostileMobs: Joi.array().items(Joi.string()).min(1).required(),
  }).required(),

  farm: Joi.object({
    enabled: Joi.boolean().default(false),
    waypointName: Joi.string().default('farm'),
    lootRadius: Joi.number().integer().min(1).max(32).default(5),
    lootIntervalMs: Joi.number().integer().min(500).default(3000),
    stuckTimeoutMs: Joi.number().integer().min(10000).default(60000),
  }).required(),

  commands: Joi.object({
    prefix: Joi.string().min(1).max(3).default('!'),
    whitelist: Joi.array().items(Joi.string()).default([]),
    responseDelay: Joi.number().integer().min(0).default(500),
  }).required(),

  autoEat: Joi.object({
    priority: Joi.string()
      .valid('foodPoints', 'saturation', 'effectiveQuality')
      .default('foodPoints'),
    startAt: Joi.number().integer().min(1).max(20).default(14),
    bannedFood: Joi.array().items(Joi.string()).default([]),
    checkOnItemPickup: Joi.boolean().default(true),
  }).required(),

  health: Joi.object({
    checkIntervalMinutes: Joi.number().integer().min(1).default(1),
    lowHealthThreshold: Joi.number().integer().min(1).max(20).default(5),
  }).required(),

  stats: Joi.object({
    saveIntervalMinutes: Joi.number().integer().min(1).default(5),
  }).required(),

  web: Joi.object({
    enabled: Joi.boolean().default(false),
    logBufferSize: Joi.number().integer().min(50).max(5000).default(500),
  }).required(),
});

module.exports = { configSchema };
