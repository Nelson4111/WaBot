'use strict';

const path = require('path');
const fse = require('fs-extra');
const { createModuleLogger } = require('../utils/logger');

const log = createModuleLogger('DataService');

// ── Konstanta ────────────────────────────────────────────────────────────────
const DATA_DIR = path.resolve(process.cwd(), 'data');

/** Nilai default untuk setiap file data */
const DEFAULT_DATA = {
  'whitelist.json': { players: [] },
  'waypoints.json': { waypoints: {} },
  'inventory.json': { lastUpdated: null, items: [] },
  'stats.json': {
    startedAt: null,
    totalDeaths: 0,
    totalLogins: 0,
    totalReconnects: 0,
    lastPosition: null,
    lastSeen: null,
    farmCycles: 0,
    totalItemsLooted: 0,
  },
};

// ── Inisialisasi Direktori dan File Default ──────────────────────────────────

/**
 * Pastikan direktori data/ dan semua file JSON default sudah ada.
 * Dipanggil satu kali saat aplikasi pertama kali start.
 */
async function initDataDir() {
  await fse.ensureDir(DATA_DIR);

  for (const [filename, defaultValue] of Object.entries(DEFAULT_DATA)) {
    const filePath = path.join(DATA_DIR, filename);
    const exists = await fse.pathExists(filePath);

    if (!exists) {
      await fse.writeJson(filePath, defaultValue, { spaces: 2 });
      log.info(`File data dibuat: ${filename}`);
    }
  }
}

// ── CRUD Operations ──────────────────────────────────────────────────────────

/**
 * Baca file JSON dari direktori data/.
 * Jika file corrupt, akan di-reset ke nilai default.
 *
 * @param {string} filename - Nama file (misal: 'whitelist.json')
 * @returns {Promise<object>} Data yang dibaca
 */
async function readData(filename) {
  const filePath = path.join(DATA_DIR, filename);

  try {
    await fse.ensureFile(filePath);
    const data = await fse.readJson(filePath, { throws: true });
    return data;
  } catch (err) {
    log.warn(`File ${filename} corrupt atau tidak valid: ${err.message}`);
    log.warn(`Mereset ${filename} ke nilai default...`);

    const defaultValue = DEFAULT_DATA[filename] || {};
    await writeData(filename, defaultValue);
    return defaultValue;
  }
}

/**
 * Tulis data ke file JSON menggunakan atomic write.
 * Write ke file temp dulu, baru rename — mencegah data corrupt jika crash.
 *
 * @param {string} filename - Nama file (misal: 'whitelist.json')
 * @param {object} data - Data yang akan ditulis
 * @returns {Promise<void>}
 */
async function writeData(filename, data) {
  const filePath = path.join(DATA_DIR, filename);
  const tempPath = `${filePath}.tmp`;

  try {
    // Tulis ke file temporary
    await fse.writeJson(tempPath, data, { spaces: 2 });
    // Rename secara atomic
    await fse.move(tempPath, filePath, { overwrite: true });
  } catch (err) {
    log.error(`Gagal menyimpan ${filename}: ${err.message}`);
    // Bersihkan file temp jika ada
    await fse.remove(tempPath).catch(() => {});
    throw err;
  }
}

/**
 * Update sebagian data dalam file JSON (partial update / merge).
 *
 * @param {string} filename - Nama file
 * @param {object} updates - Object yang akan di-merge
 * @returns {Promise<object>} Data setelah update
 */
async function updateData(filename, updates) {
  const current = await readData(filename);
  const updated = { ...current, ...updates };
  await writeData(filename, updated);
  return updated;
}

// ── Whitelist Operations ─────────────────────────────────────────────────────

/**
 * Dapatkan daftar player yang ada di whitelist.
 *
 * @returns {Promise<string[]>} Array username
 */
async function getWhitelist() {
  const data = await readData('whitelist.json');
  return data.players || [];
}

/**
 * Tambahkan player ke whitelist.
 *
 * @param {string} username - Username Minecraft (case-insensitive check)
 * @returns {Promise<boolean>} true jika berhasil ditambah, false jika sudah ada
 */
async function addToWhitelist(username) {
  const data = await readData('whitelist.json');
  const lowerUsername = username.toLowerCase();
  const existing = data.players.map((p) => p.toLowerCase());

  if (existing.includes(lowerUsername)) {
    return false;
  }

  data.players.push(username);
  await writeData('whitelist.json', data);
  return true;
}

/**
 * Hapus player dari whitelist.
 *
 * @param {string} username - Username Minecraft
 * @returns {Promise<boolean>} true jika berhasil dihapus, false jika tidak ada
 */
async function removeFromWhitelist(username) {
  const data = await readData('whitelist.json');
  const lowerUsername = username.toLowerCase();
  const initialLength = data.players.length;

  data.players = data.players.filter((p) => p.toLowerCase() !== lowerUsername);

  if (data.players.length === initialLength) {
    return false;
  }

  await writeData('whitelist.json', data);
  return true;
}

/**
 * Cek apakah player ada di whitelist.
 *
 * @param {string} username - Username Minecraft
 * @returns {Promise<boolean>}
 */
async function isWhitelisted(username) {
  const players = await getWhitelist();
  return players.some((p) => p.toLowerCase() === username.toLowerCase());
}

// ── Waypoint Operations ──────────────────────────────────────────────────────

/**
 * Dapatkan semua waypoint yang tersimpan.
 *
 * @returns {Promise<object>} Map nama → {x, y, z}
 */
async function getWaypoints() {
  const data = await readData('waypoints.json');
  return data.waypoints || {};
}

/**
 * Simpan waypoint baru.
 *
 * @param {string} name - Nama waypoint
 * @param {object} position - Posisi {x, y, z}
 * @returns {Promise<void>}
 */
async function saveWaypoint(name, position) {
  const data = await readData('waypoints.json');
  data.waypoints[name.toLowerCase()] = {
    x: Math.floor(position.x),
    y: Math.floor(position.y),
    z: Math.floor(position.z),
    savedAt: new Date().toISOString(),
  };
  await writeData('waypoints.json', data);
}

/**
 * Dapatkan satu waypoint berdasarkan nama.
 *
 * @param {string} name - Nama waypoint
 * @returns {Promise<object|null>} Posisi {x, y, z} atau null jika tidak ada
 */
async function getWaypoint(name) {
  const waypoints = await getWaypoints();
  return waypoints[name.toLowerCase()] || null;
}

/**
 * Hapus waypoint.
 *
 * @param {string} name - Nama waypoint
 * @returns {Promise<boolean>} true jika berhasil dihapus
 */
async function deleteWaypoint(name) {
  const data = await readData('waypoints.json');
  const key = name.toLowerCase();

  if (!data.waypoints[key]) return false;

  delete data.waypoints[key];
  await writeData('waypoints.json', data);
  return true;
}

// ── Stats Operations ─────────────────────────────────────────────────────────

/**
 * Dapatkan statistik bot.
 *
 * @returns {Promise<object>}
 */
async function getStats() {
  return readData('stats.json');
}

/**
 * Update statistik bot.
 *
 * @param {object} updates - Field yang akan diupdate
 * @returns {Promise<object>}
 */
async function updateStats(updates) {
  return updateData('stats.json', updates);
}

/**
 * Increment counter statistik.
 *
 * @param {string} field - Nama field counter
 * @returns {Promise<void>}
 */
async function incrementStat(field) {
  const stats = await getStats();
  stats[field] = (stats[field] || 0) + 1;
  await writeData('stats.json', stats);
}

module.exports = {
  initDataDir,
  readData,
  writeData,
  updateData,
  getWhitelist,
  addToWhitelist,
  removeFromWhitelist,
  isWhitelisted,
  getWaypoints,
  saveWaypoint,
  getWaypoint,
  deleteWaypoint,
  getStats,
  updateStats,
  incrementStat,
};
