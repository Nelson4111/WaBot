'use strict';

const Connector = require('./Connector');
const { createModuleLogger } = require('../utils/logger');
const { incrementStat, updateStats } = require('../services/DataService');

// Modules
const AutoAuth = require('../modules/AutoAuth');
const AntiAfk = require('../modules/AntiAfk');
const AutoEat = require('../modules/AutoEat');
const AutoRespawn = require('../modules/AutoRespawn');
const GuardMode = require('../modules/GuardMode');
const MobFarm = require('../modules/MobFarm');
const PathfinderModule = require('../modules/Pathfinder');

// Events
const ChatHandler = require('../events/ChatHandler');
const DeathHandler = require('../events/DeathHandler');
const ErrorHandler = require('../events/ErrorHandler');
const SpawnHandler = require('../events/SpawnHandler');

const log = createModuleLogger('BotManager');

/**
 * BotManager adalah orchestrator utama.
 * Ia mengelola lifecycle bot, menginisialisasi semua modul,
 * dan mengekspos state bot ke web dashboard.
 *
 * Pola yang digunakan: modul di-inject dengan instance bot
 * setiap kali koneksi baru terbentuk (reconnect = modul fresh).
 */
class BotManager {
  constructor() {
    /** @type {Connector} */
    this.connector = new Connector();

    /** @type {import('mineflayer').Bot|null} */
    this.bot = null;

    /** @type {number|null} Timestamp saat bot pertama kali start */
    this.startedAt = null;

    /** @type {number|null} Timestamp saat koneksi terakhir berhasil */
    this.connectedAt = null;

    /** @type {boolean} Apakah bot sedang online */
    this.isConnected = false;

    // Module instances (akan di-reset saat reconnect)
    this._modules = {
      autoAuth: null,
      antiAfk: null,
      autoEat: null,
      autoRespawn: null,
      guardMode: null,
      mobFarm: null,
      pathfinder: null,
    };

    this._setupConnectorEvents();
  }

  /**
   * Setup listener ke event yang di-emit oleh Connector.
   * Ini adalah satu-satunya tempat di mana kita bereaksi terhadap
   * perubahan status koneksi.
   *
   * @private
   */
  _setupConnectorEvents() {
    this.connector.on('connected', async (bot) => {
      this.bot = bot;
      this.isConnected = true;
      this.connectedAt = Date.now();

      if (!this.startedAt) {
        this.startedAt = Date.now();
        await updateStats({ startedAt: new Date().toISOString() }).catch(() => {});
      }

      await incrementStat('totalLogins').catch(() => {});
      log.success('Bot online dan siap menerima perintah');

      this._initModules(bot);
      this._initEventHandlers(bot);
    });

    this.connector.on('disconnected', async ({ reason }) => {
      this.isConnected = false;
      this.bot = null;

      // Stop semua module agar tidak ada zombie process
      this._stopAllModules();

      log.warn(`Bot offline. Alasan: ${reason}`);
      await updateStats({ lastSeen: new Date().toISOString() }).catch(() => {});
    });

    this.connector.on('reconnecting', async ({ attempt, delayMs }) => {
      await incrementStat('totalReconnects').catch(() => {});
      log.info(`Menunggu reconnect #${attempt} dalam ${Math.round(delayMs / 1000)}s...`);
    });
  }

  /**
   * Inisialisasi semua modul dengan bot instance yang fresh.
   * Dipanggil setiap kali bot berhasil connect/reconnect.
   *
   * @param {import('mineflayer').Bot} bot
   * @private
   */
  _initModules(bot) {
    log.info('Menginisialisasi semua modul...');

    this._modules.pathfinder = new PathfinderModule(bot);
    this._modules.autoAuth = new AutoAuth(bot);
    this._modules.antiAfk = new AntiAfk(bot);
    this._modules.autoEat = new AutoEat(bot);
    this._modules.autoRespawn = new AutoRespawn(bot);
    this._modules.guardMode = new GuardMode(bot, this._modules.pathfinder);
    this._modules.mobFarm = new MobFarm(bot, this._modules.pathfinder, this._modules.guardMode);

    // Start modul yang selalu aktif
    this._modules.autoAuth.start();
    this._modules.antiAfk.start();
    this._modules.autoEat.start();
    this._modules.autoRespawn.start();

    log.success('Semua modul berhasil diinisialisasi');
  }

  /**
   * Inisialisasi event handler untuk bot.
   *
   * @param {import('mineflayer').Bot} bot
   * @private
   */
  _initEventHandlers(bot) {
    ChatHandler.attach(bot, this);
    DeathHandler.attach(bot, this);
    ErrorHandler.attach(bot, this);
    SpawnHandler.attach(bot, this);
  }

  /**
   * Hentikan semua modul yang aktif.
   * Dipanggil saat disconnect.
   *
   * @private
   */
  _stopAllModules() {
    for (const [name, mod] of Object.entries(this._modules)) {
      if (mod && typeof mod.stop === 'function') {
        try {
          mod.stop();
        } catch (err) {
          log.warn(`Gagal menghentikan modul ${name}: ${err.message}`);
        }
      }
      this._modules[name] = null;
    }
  }

  /**
   * Mulai bot manager — entry point utama.
   *
   * @returns {void}
   */
  start() {
    log.info('BotManager dimulai');
    this.connector.connect();
  }

  /**
   * Hentikan bot manager secara permanen.
   *
   * @returns {void}
   */
  stop() {
    log.info('BotManager dihentikan');
    this._stopAllModules();
    this.connector.stop();
  }

  /**
   * Dapatkan snapshot status bot saat ini untuk dashboard.
   *
   * @returns {object} Status snapshot
   */
  getStatus() {
    if (!this.isConnected || !this.bot) {
      return {
        online: false,
        connectedAt: null,
        startedAt: this.startedAt,
        health: 0,
        food: 0,
        position: null,
        activeModes: [],
      };
    }

    const activeModes = [];
    if (this._modules.antiAfk?.isActive) activeModes.push('anti-afk');
    if (this._modules.guardMode?.isActive) activeModes.push('guard');
    if (this._modules.mobFarm?.isActive) activeModes.push('farm');

    return {
      online: true,
      username: this.bot.username,
      serverHost: this.bot.host || 'unknown',
      connectedAt: this.connectedAt,
      startedAt: this.startedAt,
      health: this.bot.health ?? 0,
      food: this.bot.food ?? 0,
      saturation: this.bot.foodSaturation ?? 0,
      position: this.bot.entity?.position
        ? {
            x: Math.floor(this.bot.entity.position.x),
            y: Math.floor(this.bot.entity.position.y),
            z: Math.floor(this.bot.entity.position.z),
          }
        : null,
      activeModes,
    };
  }

  /**
   * Akses modul-modul bot dari luar (digunakan oleh command handlers).
   *
   * @returns {object} Semua modul yang aktif
   */
  getModules() {
    return this._modules;
  }
}

module.exports = BotManager;
