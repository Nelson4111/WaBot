'use strict';

const { pathfinder } = require('mineflayer-pathfinder');

const pvp = require('mineflayer-pvp').plugin;
const autoEat = require('mineflayer-auto-eat').plugin;
const toolPlugin = require('mineflayer-tool').plugin;
const { createModuleLogger } = require('../utils/logger');

const log = createModuleLogger('PluginLoader');

/**
 * Daftar plugin Mineflayer yang akan dimuat beserta konfigurasinya.
 * Urutan penting: pathfinder harus sebelum modul yang menggunakannya.
 */
const PLUGINS = [
  { name: 'pathfinder', plugin: pathfinder },
  { name: 'pvp', plugin: pvp },
  { name: 'auto-eat', plugin: autoEat },
  { name: 'tool', plugin: toolPlugin },
];

/**
 * Muat semua plugin Mineflayer ke instance bot.
 * Setiap plugin dimuat dalam try-catch agar satu plugin gagal
 * tidak menghentikan proses load plugin lainnya.
 *
 * @param {import('mineflayer').Bot} bot - Instance bot Mineflayer
 * @returns {void}
 */
function loadPlugins(bot) {
  log.info(`Memuat ${PLUGINS.length} plugin Mineflayer...`);

  for (const { name, plugin } of PLUGINS) {
    try {
      bot.loadPlugin(plugin);
      log.success(`Plugin '${name}' berhasil dimuat`);
    } catch (err) {
      log.error(`Gagal memuat plugin '${name}': ${err.message}`);
      log.warn(`Bot akan berjalan tanpa plugin '${name}'. Beberapa fitur mungkin tidak berfungsi.`);
    }
  }
}

module.exports = { loadPlugins };
