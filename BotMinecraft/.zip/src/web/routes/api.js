'use strict';

const express = require('express');
const { createModuleLogger } = require('../../utils/logger');
const { getWaypoints } = require('../../services/DataService');
const CommandRegistry = require('../../commands/CommandRegistry');

const log = createModuleLogger('API');

/**
 * REST API routes untuk web dashboard.
 *
 * Endpoint:
 *   GET  /api/status    → Status bot (health, food, posisi, mode, uptime)
 *   GET  /api/inventory → Isi inventory bot
 *   GET  /api/waypoints → Daftar waypoint
 *   GET  /api/stats     → Statistik bot
 *   POST /api/command   → Eksekusi command dari dashboard
 *
 * @param {import('../../core/BotManager')} botManager
 * @param {import('../../services/StatsService')} statsService
 * @returns {express.Router}
 */
function apiRoutes(botManager, statsService) {
  const router = express.Router();

  // GET /api/status
  router.get('/status', (req, res) => {
    try {
      const status = botManager.getStatus();
      res.json({ success: true, data: status });
    } catch (err) {
      log.error(`GET /api/status error: ${err.message}`);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // GET /api/inventory
  router.get('/inventory', (req, res) => {
    try {
      const bot = botManager.bot;
      if (!bot) {
        return res.json({ success: true, data: { items: [], totalSlots: 0 } });
      }

      const items = bot.inventory.items().map((item) => ({
        name: item.name,
        displayName: item.displayName,
        count: item.count,
        slot: item.slot,
      }));

      res.json({ success: true, data: { items, totalSlots: items.length } });
    } catch (err) {
      log.error(`GET /api/inventory error: ${err.message}`);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // GET /api/waypoints
  router.get('/waypoints', async (req, res) => {
    try {
      const waypoints = await getWaypoints();
      res.json({ success: true, data: waypoints });
    } catch (err) {
      log.error(`GET /api/waypoints error: ${err.message}`);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // GET /api/stats
  router.get('/stats', async (req, res) => {
    try {
      const stats = await statsService.getFullStats();
      res.json({ success: true, data: stats });
    } catch (err) {
      log.error(`GET /api/stats error: ${err.message}`);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // POST /api/command — Eksekusi command dari dashboard
  // Body: { command: "!status" }
  router.post('/command', async (req, res) => {
    const { command } = req.body;

    if (!command || typeof command !== 'string') {
      return res.status(400).json({ success: false, error: 'Field "command" wajib diisi' });
    }

    const bot = botManager.bot;
    if (!bot) {
      return res
        .status(503)
        .json({ success: false, error: 'Bot sedang offline. Tunggu reconnect.' });
    }

    log.info(`Command dari dashboard: ${command}`);

    // Dispatch ke CommandRegistry dengan sender 'dashboard'
    // Dashboard tidak perlu cek whitelist — sudah aman karena LAN/VPN only
    try {
      await CommandRegistry.handleMessage(bot, botManager, '__dashboard__', command);
      res.json({ success: true, message: 'Command dieksekusi' });
    } catch (err) {
      log.error(`Error eksekusi command dashboard: ${err.message}`);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // GET /api/health — Simple health check endpoint
  router.get('/health', (req, res) => {
    res.json({
      status: 'ok',
      botOnline: botManager.isConnected,
      timestamp: new Date().toISOString(),
    });
  });

  return router;
}

module.exports = apiRoutes;
