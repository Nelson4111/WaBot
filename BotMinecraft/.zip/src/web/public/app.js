/**
 * Minecraft Bot Dashboard — Frontend JavaScript
 * Vanilla JS, no framework. Uses Fetch API + SSE for real-time data.
 */

'use strict';

// ── State ────────────────────────────────────────────────────────────────────
const state = {
  refreshInterval: null,
  sseSource: null,
  healthHistory: [],
  foodHistory: [],
  charts: { health: null, food: null },
  logEntries: [],
  currentLogFilter: 'all',
  maxHistoryPoints: 30,
};

// ── DOM Helpers ───────────────────────────────────────────────────────────────
const $ = (id) => document.getElementById(id);
const setText = (id, text) => { const el = $(id); if (el) el.textContent = text; };
const setWidth = (id, pct) => { const el = $(id); if (el) el.style.width = `${Math.max(0, Math.min(100, pct))}%`; };

// ── Tab Navigation ────────────────────────────────────────────────────────────
document.querySelectorAll('.nav-item').forEach((btn) => {
  btn.addEventListener('click', () => {
    const tab = btn.dataset.tab;
    switchTab(tab);
  });
});

function switchTab(tab) {
  // Deactivate all
  document.querySelectorAll('.nav-item').forEach((b) => b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach((c) => c.classList.remove('active'));

  // Activate selected
  const navBtn = document.querySelector(`[data-tab="${tab}"]`);
  const tabContent = $(`tab-${tab}`);

  if (navBtn) navBtn.classList.add('active');
  if (tabContent) tabContent.classList.add('active');

  // Update page title
  const titles = { dashboard: 'Dashboard', inventory: 'Inventory', waypoints: 'Waypoints', logs: 'Live Logs', commands: 'Commands' };
  setText('pageTitle', titles[tab] || tab);

  // Lazy load tab data
  if (tab === 'inventory') loadInventory();
  if (tab === 'waypoints') loadWaypoints();
}

// ── Status Refresh ────────────────────────────────────────────────────────────
async function fetchStatus() {
  try {
    const res = await fetch('/api/status');
    const json = await res.json();

    if (!json.success) throw new Error(json.error);
    updateStatusUI(json.data);
  } catch (err) {
    setOfflineUI();
  }
}

function updateStatusUI(data) {
  const dot = $('statusDot');
  const statusText = $('statusText');

  if (data.online) {
    dot.className = 'status-dot online';
    statusText.textContent = data.username || 'Online';

    // Stats cards
    const health = Math.round(data.health);
    const food = Math.round(data.food);
    setText('statHealth', `${health} / 20`);
    setText('statFood', `${food} / 20`);
    setWidth('healthBar', (health / 20) * 100);
    setWidth('foodBar', (food / 20) * 100);

    // Position
    if (data.position) {
      setText('statPosition', `X:${data.position.x} Y:${data.position.y} Z:${data.position.z}`);
    } else {
      setText('statPosition', 'Unknown');
    }

    // Uptime
    if (data.connectedAt) {
      const uptimeMs = Date.now() - data.connectedAt;
      setText('statUptime', formatDuration(uptimeMs));
    }

    // Modes
    const modesEl = $('modeBadges');
    if (modesEl) {
      if (data.activeModes.length === 0) {
        modesEl.innerHTML = '<span class="badge badge-idle">idle</span>';
      } else {
        modesEl.innerHTML = data.activeModes
          .map((m) => `<span class="badge badge-${m}">${m}</span>`)
          .join('');
      }
    }

    // Chart history
    const now = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    addChartPoint(now, health, food);

  } else {
    dot.className = 'status-dot offline';
    statusText.textContent = 'Offline';
    setOfflineUI();
  }

  // Update timestamp
  setText('lastUpdate', new Date().toLocaleTimeString('id-ID'));
}

function setOfflineUI() {
  const dot = $('statusDot');
  if (dot) dot.className = 'status-dot offline';
  setText('statHealth', '— / 20');
  setText('statFood', '— / 20');
  setWidth('healthBar', 0);
  setWidth('foodBar', 0);
  setText('statPosition', 'Offline');
  setText('statUptime', '—');
  const modesEl = $('modeBadges');
  if (modesEl) modesEl.innerHTML = '<span class="badge badge-idle">offline</span>';
}

// ── Stats ─────────────────────────────────────────────────────────────────────
async function fetchStats() {
  try {
    const res = await fetch('/api/stats');
    const json = await res.json();
    if (!json.success) return;

    const s = json.data;
    setText('statDeaths', s.totalDeaths ?? '0');
    setText('statLogins', s.totalLogins ?? '0');
    setText('statReconnects', s.totalReconnects ?? '0');
    setText('statItems', s.totalItemsLooted ?? '0');
    setText('statFarmCycles', s.farmCycles ?? '0');
    setText('statLastSeen', s.lastSeen ? new Date(s.lastSeen).toLocaleString('id-ID') : '—');
  } catch (err) {
    // Silent fail
  }
}

// ── Charts ────────────────────────────────────────────────────────────────────
function initCharts() {
  const chartDefaults = {
    type: 'line',
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { ticks: { color: '#475569', font: { size: 10 } }, grid: { color: 'rgba(255,255,255,0.04)' } },
        y: { min: 0, max: 20, ticks: { color: '#475569', font: { size: 10 } }, grid: { color: 'rgba(255,255,255,0.04)' } },
      },
      animation: { duration: 300 },
      elements: { point: { radius: 2 }, line: { tension: 0.4 } },
    },
  };

  const hCtx = $('healthChart')?.getContext('2d');
  const fCtx = $('foodChart')?.getContext('2d');

  if (hCtx) {
    state.charts.health = new Chart(hCtx, {
      ...chartDefaults,
      data: {
        labels: [],
        datasets: [{
          data: [],
          borderColor: '#ef4444',
          backgroundColor: 'rgba(239, 68, 68, 0.08)',
          fill: true,
          borderWidth: 2,
        }],
      },
    });
  }

  if (fCtx) {
    state.charts.food = new Chart(fCtx, {
      ...chartDefaults,
      data: {
        labels: [],
        datasets: [{
          data: [],
          borderColor: '#f59e0b',
          backgroundColor: 'rgba(245, 158, 11, 0.08)',
          fill: true,
          borderWidth: 2,
        }],
      },
    });
  }
}

function addChartPoint(label, health, food) {
  for (const [chart, value] of [[state.charts.health, health], [state.charts.food, food]]) {
    if (!chart) continue;
    chart.data.labels.push(label);
    chart.data.datasets[0].data.push(value);
    if (chart.data.labels.length > state.maxHistoryPoints) {
      chart.data.labels.shift();
      chart.data.datasets[0].data.shift();
    }
    chart.update('none');
  }
}

// ── Inventory ─────────────────────────────────────────────────────────────────
async function loadInventory() {
  const grid = $('inventoryGrid');
  if (!grid) return;
  grid.innerHTML = '<div class="empty-state">Loading...</div>';

  try {
    const res = await fetch('/api/inventory');
    const json = await res.json();
    if (!json.success) throw new Error(json.error);

    const { items } = json.data;

    if (items.length === 0) {
      grid.innerHTML = '<div class="empty-state">Inventory kosong</div>';
      return;
    }

    // Gabungkan item yang sama
    const itemMap = {};
    for (const item of items) {
      const key = item.name;
      if (itemMap[key]) {
        itemMap[key].count += item.count;
      } else {
        itemMap[key] = { ...item };
      }
    }

    grid.innerHTML = Object.values(itemMap)
      .sort((a, b) => b.count - a.count)
      .map((item) => `
        <div class="inventory-item">
          <div class="inventory-item-name">${formatItemName(item.name)}</div>
          <div class="inventory-item-count">×${item.count}</div>
        </div>
      `)
      .join('');
  } catch (err) {
    grid.innerHTML = `<div class="empty-state">Error: ${err.message}</div>`;
  }
}

// ── Waypoints ─────────────────────────────────────────────────────────────────
async function loadWaypoints() {
  const list = $('waypointsList');
  if (!list) return;
  list.innerHTML = '<div class="empty-state">Loading...</div>';

  try {
    const res = await fetch('/api/waypoints');
    const json = await res.json();
    if (!json.success) throw new Error(json.error);

    const waypoints = json.data;
    const entries = Object.entries(waypoints);

    if (entries.length === 0) {
      list.innerHTML = '<div class="empty-state">Belum ada waypoint. Gunakan !waypoint add &lt;nama&gt; di in-game.</div>';
      return;
    }

    list.innerHTML = entries
      .map(([name, pos]) => `
        <div class="waypoint-card">
          <span class="waypoint-name">📍 ${name}</span>
          <span class="waypoint-coords">X:${pos.x} Y:${pos.y} Z:${pos.z}</span>
          <div class="waypoint-actions">
            <button class="btn btn-sm" onclick="quickCmd('!waypoint go ${name}')">Go</button>
          </div>
        </div>
      `)
      .join('');
  } catch (err) {
    list.innerHTML = `<div class="empty-state">Error: ${err.message}</div>`;
  }
}

// ── Live Logs (SSE) ───────────────────────────────────────────────────────────
function connectSSE() {
  if (state.sseSource) state.sseSource.close();

  state.sseSource = new EventSource('/api/logs/stream');

  state.sseSource.addEventListener('log', (e) => {
    const entry = JSON.parse(e.data);
    if (entry.type === 'ping') return;
    addLogEntry(entry);
  });

  state.sseSource.onerror = () => {
    setTimeout(connectSSE, 5000); // Reconnect SSE
  };
}

function addLogEntry(entry) {
  state.logEntries.push(entry);
  if (state.logEntries.length > 1000) state.logEntries.shift();

  const container = $('logContainer');
  if (!container) return;

  const level = (entry.level || 'info').toLowerCase();
  const time = entry.timestamp ? entry.timestamp.split(' ')[1] || '' : '';
  const hidden = state.currentLogFilter !== 'all' && level !== state.currentLogFilter;

  const el = document.createElement('div');
  el.className = `log-entry ${hidden ? 'hidden' : ''}`;
  el.dataset.level = level;
  el.innerHTML = `
    <span class="log-time">${time}</span>
    <span class="log-level log-level-${level}">[${level.toUpperCase()}]</span>
    <span class="log-message">${escapeHtml(entry.message || '')}</span>
  `;

  container.appendChild(el);

  // Auto-scroll
  const autoScroll = $('autoScrollLogs');
  if (autoScroll?.checked) {
    container.scrollTop = container.scrollHeight;
  }

  // Max entries di DOM (performance)
  const allEntries = container.querySelectorAll('.log-entry');
  if (allEntries.length > 500) {
    allEntries[0].remove();
  }
}

function filterLogs() {
  const filter = $('logLevelFilter')?.value || 'all';
  state.currentLogFilter = filter;

  document.querySelectorAll('.log-entry').forEach((el) => {
    const level = el.dataset.level;
    if (filter === 'all' || level === filter) {
      el.classList.remove('hidden');
    } else {
      el.classList.add('hidden');
    }
  });
}

function clearLogs() {
  const container = $('logContainer');
  if (container) container.innerHTML = '';
  state.logEntries = [];
}

// ── Commands ──────────────────────────────────────────────────────────────────
async function sendCommand() {
  const input = $('commandInput');
  const response = $('commandResponse');
  const command = input?.value?.trim();

  if (!command) return;

  response.className = 'command-response visible';
  response.textContent = 'Mengirim...';

  try {
    const res = await fetch('/api/command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command }),
    });
    const json = await res.json();

    if (json.success) {
      response.className = 'command-response visible success';
      response.textContent = `✓ "${command}" dikirim ke bot`;
    } else {
      response.className = 'command-response visible error';
      response.textContent = `✗ Error: ${json.error}`;
    }
  } catch (err) {
    response.className = 'command-response visible error';
    response.textContent = `✗ Network error: ${err.message}`;
  }

  input.value = '';
}

function quickCmd(cmd) {
  const input = $('commandInput');
  if (input) input.value = cmd;
  sendCommand();
}

// ── Keyboard Shortcuts ────────────────────────────────────────────────────────
document.addEventListener('keydown', (e) => {
  if (e.target === $('commandInput') && e.key === 'Enter') {
    sendCommand();
  }
});

// ── Refresh ───────────────────────────────────────────────────────────────────
async function refreshAll() {
  await Promise.all([fetchStatus(), fetchStats()]);
}

// ── Utilities ─────────────────────────────────────────────────────────────────
function formatDuration(ms) {
  if (!ms || ms < 0) return '0h 0m 0s';
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m ${s % 60}s`;
}

function formatItemName(name) {
  if (!name) return 'Unknown';
  return name.split('_').map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ── Init ──────────────────────────────────────────────────────────────────────
function init() {
  initCharts();
  connectSSE();
  refreshAll();

  // Auto-refresh setiap 5 detik
  state.refreshInterval = setInterval(refreshAll, 5000);
}

// Jalankan setelah DOM siap
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
