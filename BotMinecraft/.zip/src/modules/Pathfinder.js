'use strict';

const { goals } = require('mineflayer-pathfinder');
const { createModuleLogger } = require('../utils/logger');
const config = require('../config');

const log = createModuleLogger('Pathfinder');

/** Timeout untuk mendeteksi bot yang stuck (tidak bergerak) */
const STUCK_CHECK_INTERVAL_MS = 5000;

/**
 * PathfinderModule adalah wrapper high-level di atas mineflayer-pathfinder.
 * Menyediakan API yang lebih sederhana untuk navigasi ke koordinat atau waypoint.
 *
 * Fitur:
 * - Goto koordinat (x, y, z) atau (x, z) dengan auto y
 * - Timeout otomatis jika stuck
 * - Cancel path yang sedang berjalan
 */
class PathfinderModule {
  /**
   * @param {import('mineflayer').Bot} bot
   */
  constructor(bot) {
    this.bot = bot;
    this.isMoving = false;
    this._stuckTimer = null;
    this._lastPosition = null;
  }

  /**
   * Navigasikan bot ke koordinat target.
   *
   * @param {number} x - Target X
   * @param {number} z - Target Z
   * @param {number} [y] - Target Y (opsional, jika tidak diisi bot akan cari sendiri)
   * @param {number} [range=2] - Toleransi jarak dari target (blok)
   * @returns {Promise<void>}
   * @throws {Error} Jika pathfinding gagal atau timeout
   */
  async goto(x, z, y = null, range = 2) {
    if (!this.bot.pathfinder) {
      throw new Error('Plugin pathfinder belum di-load');
    }

    if (this.isMoving) {
      log.warn('Bot sudah sedang bergerak. Membatalkan path sebelumnya...');
      this.stop();
    }

    this.isMoving = true;
    this._startStuckDetection();

    log.info(`Bergerak ke X:${x} Y:${y ?? 'auto'} Z:${z} (range: ${range})`);

    return new Promise((resolve, reject) => {
      // Set goal dengan range tolerance (GoalNear lebih fleksibel)
      const goalWithRange = new goals.GoalNear(
        Math.floor(x),
        y !== null ? Math.floor(y) : Math.floor(this.bot.entity.position.y),
        Math.floor(z),
        range
      );

      this.bot.pathfinder.setGoal(goalWithRange, false);


      const onGoalReached = () => {
        this._cleanup();
        log.success(`Berhasil sampai di X:${x} Z:${z}`);
        resolve();
      };

      const onPathUpdate = (result) => {
        if (result.status === 'noPath') {
          this._cleanup();
          this.bot.removeListener('goal_reached', onGoalReached);
          this.bot.removeListener('path_update', onPathUpdate);
          reject(new Error(`Tidak ada path ke X:${x} Z:${z}`));
        }
      };

      // Timeout anti-stuck
      const stuckTimeout = setTimeout(
        () => {
          this._cleanup();
          this.bot.removeListener('goal_reached', onGoalReached);
          this.bot.removeListener('path_update', onPathUpdate);
          reject(new Error(`Timeout: bot stuck saat menuju X:${x} Z:${z}`));
        },
        config.farm.stuckTimeoutMs
      );

      this.bot.once('goal_reached', () => {
        clearTimeout(stuckTimeout);
        onGoalReached();
      });

      this.bot.on('path_update', onPathUpdate);

      // Cleanup listener saat goal dicapai
      this.bot.once('goal_reached', () => {
        this.bot.removeListener('path_update', onPathUpdate);
      });
    });
  }

  /**
   * Hentikan pergerakan bot.
   *
   * @returns {void}
   */
  stop() {
    if (this.bot.pathfinder) {
      this.bot.pathfinder.stop();
    }
    this._cleanup();
    log.info('Pathfinder dihentikan');
  }

  /**
   * Mulai deteksi stuck: cek apakah bot tidak bergerak sama sekali.
   *
   * @private
   */
  _startStuckDetection() {
    this._lastPosition = this.bot.entity?.position
      ? { ...this.bot.entity.position }
      : null;

    this._stuckTimer = setInterval(() => {
      const pos = this.bot.entity?.position;
      if (!pos || !this._lastPosition) return;

      const moved =
        Math.abs(pos.x - this._lastPosition.x) > 0.1 ||
        Math.abs(pos.z - this._lastPosition.z) > 0.1;

      if (!moved) {
        log.debug('Bot terdeteksi tidak bergerak...');
      }

      this._lastPosition = { ...pos };
    }, STUCK_CHECK_INTERVAL_MS);
  }

  /**
   * Bersihkan state setelah navigasi selesai atau gagal.
   *
   * @private
   */
  _cleanup() {
    this.isMoving = false;
    if (this._stuckTimer) {
      clearInterval(this._stuckTimer);
      this._stuckTimer = null;
    }
    this._lastPosition = null;
  }
}

module.exports = PathfinderModule;
