'use strict';

const { createModuleLogger } = require('../utils/logger');
const config = require('../config');
const { getWaypoint } = require('../services/DataService');
const { incrementStat } = require('../services/DataService');
const { sleep } = require('../utils/retry');

const log = createModuleLogger('MobFarm');

/**
 * MobFarm mengautomasi proses di mob grinder:
 * 1. Pergi ke waypoint 'farm' (atau waypoint custom)
 * 2. Aktifkan guard mode untuk membunuh mob
 * 3. Secara periodik kumpulkan item/loot di sekitar
 * 4. Loop terus sampai di-stop
 *
 * Alur:
 * start() → goto farm waypoint → activate guard → collect loot loop
 */
class MobFarm {
  /**
   * @param {import('mineflayer').Bot} bot
   * @param {import('./Pathfinder')} pathfinder
   * @param {import('./GuardMode')} guardMode
   */
  constructor(bot, pathfinder, guardMode) {
    this.bot = bot;
    this.pathfinder = pathfinder;
    this.guardMode = guardMode;
    this.isActive = false;
    this._lootInterval = null;
    this._farmPosition = null;
  }

  /**
   * Mulai mode farming.
   * Bot akan pergi ke waypoint farm, lalu mulai guard + loot collection.
   *
   * @returns {Promise<void>}
   */
  async start() {
    if (this.isActive) {
      log.warn('Farm mode sudah aktif');
      return;
    }

    // Cari waypoint farm
    const waypointName = config.farm.waypointName;
    const waypoint = await getWaypoint(waypointName);

    if (!waypoint) {
      log.warn(
        `Waypoint '${waypointName}' tidak ditemukan. Set waypoint dulu dengan !waypoint add ${waypointName}`
      );
      return;
    }

    this.isActive = true;
    this._farmPosition = waypoint;

    log.success(
      `Farm mode dimulai. Menuju waypoint '${waypointName}' di X:${waypoint.x} Y:${waypoint.y} Z:${waypoint.z}`
    );

    try {
      // Navigasi ke farm
      await this.pathfinder.goto(waypoint.x, waypoint.z, waypoint.y);
      log.success('Sampai di farm. Mengaktifkan guard mode...');

      // Aktifkan guard
      this.guardMode.start();

      // Mulai loot collection loop
      this._startLootCollection();

      log.success('Farm mode berjalan. Guard + loot collection aktif.');
    } catch (err) {
      log.error(`Gagal navigasi ke farm: ${err.message}`);
      this.stop();
    }
  }

  /**
   * Hentikan mode farming.
   *
   * @returns {void}
   */
  stop() {
    if (!this.isActive) return;

    this.isActive = false;
    this._stopLootCollection();

    // Stop guard mode jika sedang aktif karena farm
    if (this.guardMode.isActive) {
      this.guardMode.stop();
    }

    // Stop navigasi jika sedang berjalan
    if (this.pathfinder.isMoving) {
      this.pathfinder.stop();
    }

    this._farmPosition = null;
    log.info('Farm mode dihentikan');
  }

  /**
   * Toggle farm mode.
   *
   * @returns {boolean} Status baru
   */
  async toggle() {
    if (this.isActive) {
      this.stop();
      return false;
    } else {
      await this.start();
      return this.isActive;
    }
  }

  /**
   * Mulai loop pengumpulan loot.
   * Setiap N ms, bot akan bergerak ke item di dekatnya dan memungutnya.
   *
   * @private
   */
  _startLootCollection() {
    this._lootInterval = setInterval(async () => {
      if (!this.isActive) return;
      await this._collectNearbyItems().catch((err) => {
        log.debug(`Error saat collect loot: ${err.message}`);
      });
    }, config.farm.lootIntervalMs);
  }

  /**
   * Hentikan loop pengumpulan loot.
   *
   * @private
   */
  _stopLootCollection() {
    if (this._lootInterval) {
      clearInterval(this._lootInterval);
      this._lootInterval = null;
    }
  }

  /**
   * Kumpulkan item yang ada di dekat bot.
   * Bot tidak perlu berjalan jauh — hanya item dalam radius kecil.
   *
   * @private
   */
  async _collectNearbyItems() {
    if (!this.bot.entity) return;

    const lootRadius = config.farm.lootRadius;
    const nearbyItems = Object.values(this.bot.entities).filter((entity) => {
      if (entity.type !== 'object' && entity.objectType !== 'Item') return false;
      if (!entity.position) return false;

      const dist = entity.position.distanceTo(this.bot.entity.position);
      return dist < lootRadius;
    });

    if (nearbyItems.length === 0) return;

    log.debug(`Mengumpulkan ${nearbyItems.length} item di sekitar...`);

    // Jangan bergerak terlalu jauh dari farm position — hanya grab items dalam radius
    for (const item of nearbyItems.slice(0, 5)) {
      // Batasi 5 item per cycle
      if (!this.isActive) break;

      try {
        // Mineflayer auto-pickup items saat dekat, kita hanya perlu bergerak ke sana
        if (item.position && this._farmPosition) {
          // Jangan terlalu jauh dari farm position
          const distFromFarm = item.position.distanceTo({
            x: this._farmPosition.x,
            y: this._farmPosition.y,
            z: this._farmPosition.z,
          });

          if (distFromFarm > lootRadius * 2) continue;
        }

        await incrementStat('totalItemsLooted').catch(() => {});
        await sleep(100); // Small delay between pickups
      } catch (_err) {
        // Silent — loot collection tidak perlu crash
      }
    }
  }
}

module.exports = MobFarm;
