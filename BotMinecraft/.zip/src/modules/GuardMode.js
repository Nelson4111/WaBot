'use strict';

const { createModuleLogger } = require('../utils/logger');
const config = require('../config');
const { formatMobName } = require('../utils/formatter');

const log = createModuleLogger('GuardMode');

/** Set nama mob hostile yang dikenali */
const HOSTILE_MOB_SET = new Set(config.guard.hostileMobs);

/**
 * GuardMode memindai entity dalam radius tertentu dan menyerang
 * mob hostile menggunakan plugin mineflayer-pvp.
 *
 * Fitur:
 * - Scan entity setiap N ms (configurable)
 * - Filter hanya mob hostile dari daftar di config.json
 * - Toggle on/off via command !guard
 * - Stop otomatis saat bot mati
 */
class GuardMode {
  /**
   * @param {import('mineflayer').Bot} bot
   * @param {import('./Pathfinder')} pathfinder
   */
  constructor(bot, pathfinder) {
    this.bot = bot;
    this.pathfinder = pathfinder;
    this.isActive = false;
    this._scanInterval = null;
  }

  /**
   * Aktifkan guard mode.
   *
   * @returns {void}
   */
  start() {
    if (this.isActive) {
      log.warn('Guard mode sudah aktif');
      return;
    }

    if (!this.bot.pvp) {
      log.warn('Plugin mineflayer-pvp tidak tersedia. Guard mode tidak bisa diaktifkan.');
      return;
    }

    this.isActive = true;
    this._startScan();
    log.success(`Guard mode aktif — radius: ${config.guard.radius} blok`);
  }

  /**
   * Nonaktifkan guard mode.
   *
   * @returns {void}
   */
  stop() {
    if (!this.isActive) return;

    this.isActive = false;
    this._stopScan();

    // Hentikan serangan yang sedang berlangsung
    if (this.bot.pvp) {
      this.bot.pvp.stop();
    }

    log.info('Guard mode nonaktif');
  }

  /**
   * Toggle guard mode.
   *
   * @returns {boolean} Status baru (true = aktif)
   */
  toggle() {
    if (this.isActive) {
      this.stop();
    } else {
      this.start();
    }
    return this.isActive;
  }

  /**
   * Mulai scan periodik untuk mencari mob hostile.
   *
   * @private
   */
  _startScan() {
    this._scanInterval = setInterval(() => {
      this._scanAndAttack();
    }, config.guard.attackInterval);
  }

  /**
   * Hentikan scan periodik.
   *
   * @private
   */
  _stopScan() {
    if (this._scanInterval) {
      clearInterval(this._scanInterval);
      this._scanInterval = null;
    }
  }

  /**
   * Scan entity di sekitar bot dan serang mob hostile terdekat.
   *
   * @private
   */
  _scanAndAttack() {
    if (!this.isActive || !this.bot.entity) return;

    // Jika sedang menyerang, tidak perlu cari target baru
    if (this.bot.pvp.target) return;

    const target = this._findNearestHostile();

    if (target) {
      log.debug(`Menyerang ${formatMobName(target.name)} (${target.id})`);
      this.bot.pvp.attack(target);
    }
  }

  /**
   * Temukan mob hostile terdekat dalam radius yang dikonfigurasi.
   *
   * @returns {import('prismarine-entity').Entity|null}
   * @private
   */
  _findNearestHostile() {
    const entities = Object.values(this.bot.entities);
    let nearest = null;
    let nearestDistance = config.guard.radius;

    for (const entity of entities) {
      // Skip bukan mob
      if (entity.type !== 'mob') continue;
      // Skip jika bukan hostile mob yang dikenal
      if (!HOSTILE_MOB_SET.has(entity.name)) continue;
      // Skip entitas yang mati
      if (entity.metadata?.[8] === 1) continue;

      const distance = entity.position?.distanceTo(this.bot.entity.position);
      if (distance && distance < nearestDistance) {
        nearestDistance = distance;
        nearest = entity;
      }
    }

    return nearest;
  }
}

module.exports = GuardMode;
