'use strict';

const { createModuleLogger } = require('../utils/logger');
const { updateStats } = require('../services/DataService');
const { formatPosition } = require('../utils/formatter');

const log = createModuleLogger('SpawnHandler');

/**
 * SpawnHandler menangani event spawn (pertama kali masuk dunia)
 * dan respawn setelah kematian.
 */
const SpawnHandler = {
  /**
   * @param {import('mineflayer').Bot} bot
   * @param {import('../core/BotManager')} botManager
   */
  attach(bot, _botManager) {
    bot.on('spawn', async () => {
      const pos = bot.entity?.position;
      const posStr = formatPosition(pos);

      log.info(`Bot spawn di posisi ${posStr}`);

      // Update stats dengan posisi spawn
      try {
        await updateStats({
          lastPosition: pos
            ? {
                x: Math.floor(pos.x),
                y: Math.floor(pos.y),
                z: Math.floor(pos.z),
              }
            : null,
          lastSeen: new Date().toISOString(),
        });
      } catch (err) {
        log.error(`Gagal update stats spawn: ${err.message}`);
      }

      // Log health dan food saat spawn
      log.info(`Health: ${bot.health}/20, Food: ${bot.food}/20`);
    });

    // Update posisi terakhir secara periodik (setiap 30 detik)
    const POSITION_SAVE_INTERVAL = 30_000;
    const positionInterval = setInterval(async () => {
      if (!bot.entity?.position) return;
      try {
        await updateStats({
          lastPosition: {
            x: Math.floor(bot.entity.position.x),
            y: Math.floor(bot.entity.position.y),
            z: Math.floor(bot.entity.position.z),
          },
          lastSeen: new Date().toISOString(),
        });
      } catch (_err) {
        // Silent — tidak perlu log setiap 30 detik
      }
    }, POSITION_SAVE_INTERVAL);

    // Bersihkan interval saat bot end
    bot.once('end', () => {
      clearInterval(positionInterval);
    });

    log.info('SpawnHandler aktif');
  },
};

module.exports = SpawnHandler;
