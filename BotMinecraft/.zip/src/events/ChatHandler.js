'use strict';

const { createModuleLogger } = require('../utils/logger');
const CommandRegistry = require('../commands/CommandRegistry');

const log = createModuleLogger('ChatHandler');

/**
 * ChatHandler mendengarkan semua chat dari server dan
 * merouting pesan yang merupakan command ke CommandRegistry.
 *
 * Juga log semua chat yang masuk untuk keperluan debugging.
 */
const ChatHandler = {
  /**
   * Attach chat listener ke bot.
   *
   * @param {import('mineflayer').Bot} bot
   * @param {import('../core/BotManager')} botManager
   */
  attach(bot, botManager) {
    // Dengarkan semua chat (player chat)
    bot.on('chat', async (username, message) => {
      // Jangan proses pesan dari bot sendiri
      if (username === bot.username) return;

      log.debug(`[CHAT] <${username}> ${message}`);

      // Cek apakah pesan adalah command
      await CommandRegistry.handleMessage(bot, botManager, username, message).catch((err) => {
        log.error(`Error saat handle command dari ${username}: ${err.message}`);
      });
    });

    // Dengarkan whisper (pesan privat)
    bot.on('whisper', async (username, message) => {
      if (username === bot.username) return;

      log.debug(`[WHISPER] <${username}> ${message}`);

      // Whisper juga bisa jadi command
      await CommandRegistry.handleMessage(bot, botManager, username, message, true).catch(
        (err) => {
          log.error(`Error saat handle whisper command dari ${username}: ${err.message}`);
        }
      );
    });

    // Log pesan sistem dari server
    bot.on('message', (jsonMsg) => {
      const text = jsonMsg.toString();
      if (text && text.trim()) {
        log.debug(`[SERVER] ${text}`);
      }
    });

    log.info('ChatHandler aktif');
  },
};

module.exports = ChatHandler;
