'use strict';

const {
  addToWhitelist,
  removeFromWhitelist,
  getWhitelist,
} = require('../services/DataService');
const { createModuleLogger } = require('../utils/logger');
const { sleep } = require('../utils/retry');

const log = createModuleLogger('WhitelistCommand');

/**
 * !whitelist <sub-command> [player]
 *
 * Sub-commands:
 *   !whitelist add <player>    → Tambah player ke whitelist
 *   !whitelist remove <player> → Hapus player dari whitelist
 *   !whitelist list            → Tampilkan semua player di whitelist
 */
const WhitelistCommand = {
  /**
   * @param {import('mineflayer').Bot} bot
   * @param {import('../core/BotManager')} _botManager
   * @param {string[]} args
   * @param {string} sender
   */
  async handle(bot, _botManager, args, sender) {
    const subCmd = (args[0] || '').toLowerCase();
    const target = args[1];

    switch (subCmd) {
      case 'add':
        await handleAdd(bot, target, sender);
        break;
      case 'remove':
      case 'del':
      case 'delete':
        await handleRemove(bot, target, sender);
        break;
      case 'list':
      case 'ls':
        await handleList(bot);
        break;
      default:
        bot.chat('Usage: !whitelist add/remove/list <player>');
    }
  },
};

async function handleAdd(bot, target, sender) {
  if (!target) {
    bot.chat('Usage: !whitelist add <player>');
    return;
  }

  const added = await addToWhitelist(target);
  if (added) {
    bot.chat(`${target} ditambahkan ke whitelist`);
    log.success(`${sender} menambahkan '${target}' ke whitelist`);
  } else {
    bot.chat(`${target} sudah ada di whitelist`);
  }
}

async function handleRemove(bot, target, sender) {
  if (!target) {
    bot.chat('Usage: !whitelist remove <player>');
    return;
  }

  const removed = await removeFromWhitelist(target);
  if (removed) {
    bot.chat(`${target} dihapus dari whitelist`);
    log.info(`${sender} menghapus '${target}' dari whitelist`);
  } else {
    bot.chat(`${target} tidak ada di whitelist`);
  }
}

async function handleList(bot) {
  const players = await getWhitelist();

  if (players.length === 0) {
    bot.chat('Whitelist kosong (semua player bisa command)');
    return;
  }

  bot.chat(`=== Whitelist (${players.length}) ===`);
  await sleep(200);
  bot.chat(players.join(', '));
}

module.exports = WhitelistCommand;
