'use strict';

/**
 * !eat — Paksa bot makan sekarang (tanpa menunggu food level turun).
 */
const EatCommand = {
  /**
   * @param {import('mineflayer').Bot} bot
   * @param {import('../core/BotManager')} botManager
   */
  async handle(bot, botManager) {
    const { autoEat } = botManager.getModules();

    if (!autoEat) {
      bot.chat('Modul auto-eat tidak tersedia');
      return;
    }

    const currentFood = Math.round(bot.food ?? 0);
    if (currentFood >= 20) {
      bot.chat(`Food sudah penuh (${currentFood}/20)`);
      return;
    }

    bot.chat(`Makan... (food: ${currentFood}/20)`);
    await autoEat.forceEat();
  },
};

module.exports = EatCommand;
