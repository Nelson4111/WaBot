'use strict';

const { createModuleLogger } = require('../utils/logger');

const log = createModuleLogger('GotoCommand');

/**
 * !goto <x> <z> [y] — Perintahkan bot navigasi ke koordinat tertentu.
 *
 * Usage:
 *   !goto 100 -200       → goto X:100 Z:-200 (Y otomatis)
 *   !goto 100 -200 64    → goto X:100 Y:64 Z:-200
 */
const GotoCommand = {
  /**
   * @param {import('mineflayer').Bot} bot
   * @param {import('../core/BotManager')} botManager
   * @param {string[]} args
   */
  async handle(bot, botManager, args) {
    if (args.length < 2) {
      bot.chat('Usage: !goto <x> <z> [y]');
      return;
    }

    const x = parseInt(args[0], 10);
    const z = parseInt(args[1], 10);
    const y = args[2] !== undefined ? parseInt(args[2], 10) : null;

    if (isNaN(x) || isNaN(z) || (args[2] !== undefined && isNaN(y))) {
      bot.chat('Koordinat harus berupa angka. Contoh: !goto 100 -200');
      return;
    }

    const { pathfinder } = botManager.getModules();
    if (!pathfinder) {
      bot.chat('Pathfinder tidak tersedia');
      return;
    }

    bot.chat(`Menuju X:${x} Y:${y ?? 'auto'} Z:${z}...`);

    try {
      await pathfinder.goto(x, z, y);
      bot.chat(`Sampai di X:${x} Z:${z}!`);
    } catch (err) {
      log.warn(`Gagal goto: ${err.message}`);
      bot.chat(`Gagal: ${err.message}`);
    }
  },
};

module.exports = GotoCommand;
