'use strict';

const { createModuleLogger } = require('../utils/logger');

const log = createModuleLogger('FarmCommand');

/**
 * !farm — Toggle mode farming on/off.
 * Jika waypoint 'farm' belum diset, akan memberitahu cara menyetnya.
 */
const FarmCommand = {
  /**
   * @param {import('mineflayer').Bot} bot
   * @param {import('../core/BotManager')} botManager
   */
  async handle(bot, botManager) {
    const { mobFarm } = botManager.getModules();

    if (!mobFarm) {
      bot.chat('Modul farm tidak tersedia');
      return;
    }

    const newState = await mobFarm.toggle();

    if (newState) {
      bot.chat('Farm mode: ON — Menuju farm...');
    } else {
      bot.chat('Farm mode: OFF');
    }
  },
};

module.exports = FarmCommand;
