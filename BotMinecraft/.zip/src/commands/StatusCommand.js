'use strict';

const { formatPosition, formatBar } = require('../utils/formatter');
const { getUptime, formatTimestamp } = require('../utils/time');
const { sleep } = require('../utils/retry');

/**
 * !status — Tampilkan status lengkap bot saat ini.
 * Output: health, food, posisi, uptime, mode aktif.
 */
const StatusCommand = {
  /**
   * @param {import('mineflayer').Bot} bot
   * @param {import('../core/BotManager')} botManager
   */
  async handle(bot, botManager) {
    const status = botManager.getStatus();
    const health = Math.round(bot.health ?? 0);
    const food = Math.round(bot.food ?? 0);
    const pos = formatPosition(bot.entity?.position);
    const uptime = getUptime(botManager.connectedAt);
    const activeModes = status.activeModes.length > 0 ? status.activeModes.join(', ') : 'idle';

    const healthBar = formatBar(health, 20);
    const foodBar = formatBar(food, 20);

    bot.chat(`=== Status Bot ===`);
    await sleep(150);
    bot.chat(`❤ HP: [${healthBar}] ${health}/20`);
    await sleep(150);
    bot.chat(`🍖 Food: [${foodBar}] ${food}/20`);
    await sleep(150);
    bot.chat(`📍 Posisi: ${pos}`);
    await sleep(150);
    bot.chat(`⏱ Uptime: ${uptime}`);
    await sleep(150);
    bot.chat(`🔧 Mode: ${activeModes}`);
  },
};

module.exports = StatusCommand;
