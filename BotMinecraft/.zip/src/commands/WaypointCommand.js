'use strict';

const { saveWaypoint, getWaypoint, getWaypoints, deleteWaypoint } = require('../services/DataService');
const { formatPosition } = require('../utils/formatter');
const { createModuleLogger } = require('../utils/logger');
const { sleep } = require('../utils/retry');

const log = createModuleLogger('WaypointCommand');

/**
 * !waypoint <sub-command> [nama]
 *
 * Sub-commands:
 *   !waypoint add <nama>    → Simpan posisi bot saat ini sebagai waypoint
 *   !waypoint go <nama>     → Navigasi ke waypoint
 *   !waypoint list          → Tampilkan semua waypoint
 *   !waypoint delete <nama> → Hapus waypoint
 */
const WaypointCommand = {
  /**
   * @param {import('mineflayer').Bot} bot
   * @param {import('../core/BotManager')} botManager
   * @param {string[]} args
   */
  async handle(bot, botManager, args) {
    const subCmd = (args[0] || '').toLowerCase();
    const name = args[1];

    switch (subCmd) {
      case 'add':
      case 'save':
        await handleAdd(bot, name);
        break;
      case 'go':
      case 'goto':
        await handleGo(bot, botManager, name);
        break;
      case 'list':
      case 'ls':
        await handleList(bot);
        break;
      case 'delete':
      case 'del':
      case 'remove':
        await handleDelete(bot, name);
        break;
      default:
        bot.chat('Usage: !waypoint add/go/list/delete <nama>');
    }
  },
};

async function handleAdd(bot, name) {
  if (!name) {
    bot.chat('Usage: !waypoint add <nama>');
    return;
  }

  if (!bot.entity?.position) {
    bot.chat('Posisi bot tidak tersedia saat ini');
    return;
  }

  await saveWaypoint(name, bot.entity.position);
  const pos = formatPosition(bot.entity.position);
  bot.chat(`Waypoint '${name}' disimpan di ${pos}`);
  log.success(`Waypoint '${name}' disimpan di ${pos}`);
}

async function handleGo(bot, botManager, name) {
  if (!name) {
    bot.chat('Usage: !waypoint go <nama>');
    return;
  }

  const waypoint = await getWaypoint(name);
  if (!waypoint) {
    bot.chat(`Waypoint '${name}' tidak ditemukan. Gunakan !waypoint list untuk melihat daftar.`);
    return;
  }

  const { pathfinder } = botManager.getModules();
  if (!pathfinder) {
    bot.chat('Pathfinder tidak tersedia');
    return;
  }

  bot.chat(`Menuju waypoint '${name}'...`);

  try {
    await pathfinder.goto(waypoint.x, waypoint.z, waypoint.y);
    bot.chat(`Sampai di waypoint '${name}'!`);
  } catch (err) {
    bot.chat(`Gagal: ${err.message}`);
  }
}

async function handleList(bot) {
  const waypoints = await getWaypoints();
  const entries = Object.entries(waypoints);

  if (entries.length === 0) {
    bot.chat('Belum ada waypoint yang disimpan');
    return;
  }

  bot.chat(`=== Waypoints (${entries.length}) ===`);
  await sleep(200);

  for (const [wpName, pos] of entries) {
    bot.chat(`${wpName}: X:${pos.x} Y:${pos.y} Z:${pos.z}`);
    await sleep(150);
  }
}

async function handleDelete(bot, name) {
  if (!name) {
    bot.chat('Usage: !waypoint delete <nama>');
    return;
  }

  const deleted = await deleteWaypoint(name);
  if (deleted) {
    bot.chat(`Waypoint '${name}' dihapus`);
  } else {
    bot.chat(`Waypoint '${name}' tidak ditemukan`);
  }
}

module.exports = WaypointCommand;
