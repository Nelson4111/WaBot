'use strict';

const { formatInventory, formatItemName } = require('../utils/formatter');
const { sleep } = require('../utils/retry');

/**
 * !inventory — Tampilkan isi inventory bot saat ini.
 * Output dikelompokkan agar tidak terlalu panjang di chat.
 */
const InventoryCommand = {
  /**
   * @param {import('mineflayer').Bot} bot
   */
  async handle(bot) {
    const items = bot.inventory.items();

    if (items.length === 0) {
      bot.chat('Inventory kosong');
      return;
    }

    const lines = formatInventory(items);
    bot.chat(`=== Inventory (${items.length} slot) ===`);
    await sleep(200);

    for (const line of lines) {
      bot.chat(line);
      await sleep(150);
    }
  },
};

module.exports = InventoryCommand;
