#!/usr/bin/env bash

# ==============================================================================
# MINECRAFT BOT LAUNCHER FOR PTERODACTYL / GAME PANELS (JAVA CONTAINERS)
# ==============================================================================

echo "=================================================="
echo " Starting Minecraft AFK Bot Launcher"
echo "=================================================="

# 1. Cek apakah 'node' sudah terinstall di sistem/container
if command -v node >/dev/null 2>&1; then
    echo "[Launcher] System Node.js ditemukan: $(node -v)"
    NODE_BIN="node"
elif [ -f "./node_dist/bin/node" ]; then
    echo "[Launcher] Portable Node.js lokal ditemukan."
    NODE_BIN="./node_dist/bin/node"
else
    echo "[Launcher] Node.js tidak ditemukan di container Java ini."
    echo "[Launcher] Mengunduh Portable Node.js v20.18.0 (Linux x64)..."
    mkdir -p node_dist
    curl -sL https://nodejs.org/dist/v20.18.0/node-v20.18.0-linux-x64.tar.xz | tar -xJ --strip-components=1 -C node_dist
    
    if [ -f "./node_dist/bin/node" ]; then
        echo "[Launcher] Berhasil mengunduh & mengekstrak Node.js!"
        NODE_BIN="./node_dist/bin/node"
    else
        echo "[ERROR] Gagal mengunduh Node.js. Pastikan container memiliki koneksi internet & curl/tar."
        exit 1
    fi
fi

# 2. Cek apakah node_modules sudah ada, jika belum jalankan npm install
if [ ! -d "./node_modules" ]; then
    echo "[Launcher] Folder node_modules belum ada. Menginstall dependencies..."
    if [ "$NODE_BIN" = "node" ]; then
        npm install --production
    else
        ./node_dist/bin/npm install --production
    fi
fi

# 3. Jalankan bot
echo "[Launcher] Memulai bot Minecraft (index.js)..."
echo "=================================================="
$NODE_BIN index.js
