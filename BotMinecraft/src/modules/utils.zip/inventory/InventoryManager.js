'use strict';

const { createModuleLogger } = require('../../utils/logger');
const config = require('../../config');
const { sleep } = require('../../utils/retry');

const log = createModuleLogger('InventoryManager');

/**
 * InventoryManager menangani:
 * - Auto Equip Weapon terbaik (Netherite > Diamond > Iron ...)
 * - Auto Drop Trash (membuang item yang tidak berguna)
 * - Helper untuk melempar/memberikan item ke owner (Give Pearl, dll)
 * - Helper penghitungan isi inventory
 */
class InventoryManager {
  /**
   * @param {import('mineflayer').Bot} bot
   * @param {import('../chat/ChatQueue')} chatQueue
   */
  constructor(bot, chatQueue) {
    this.bot = bot;
    this.chatQueue = chatQueue;
    this._autoDropInterval = null;
    this.isActive = false;
  }

  /**
   * Mulai listener dan interval auto drop.
   */
  start() {
    if (this.isActive) return;
    this.isActive = true;

    // Listen to spawn (login)
    this.bot.on('spawn', this._onSpawn.bind(this));
    
    // Listen to entity dead (bisa digunakan jika item rusak, tapi lebih aman listen update inventory)
    this.bot.inventory.on('updateSlot', (slot, oldItem, newItem) => {
       // Cek pedang saat inventory update
       // Hati-hati jangan loop
       this._checkAndEquipWeapon();
    });

    // Mulai auto drop interval
    this._autoDropInterval = setInterval(() => {
      this.dropTrash();
    }, config.inventory.autoDropIntervalMs || 120000);

    log.info('InventoryManager aktif');
  }

  /**
   * Berhenti.
   */
  stop() {
    this.isActive = false;
    if (this._autoDropInterval) {
      clearInterval(this._autoDropInterval);
      this._autoDropInterval = null;
    }
  }

  async _onSpawn() {
    await sleep(2000); // Tunggu inventory sinkron dengan server
    await this._checkAndEquipWeapon();
  }

  /**
   * Cari pedang/senjata terbaik di inventory dan equip ke tangan utama.
   *
   * @private
   */
  async _checkAndEquipWeapon() {
    if (!this.bot.inventory || !this.isActive) return;

    const items = this.bot.inventory.items();
    const priorities = config.inventory.swordPriority || ['netherite_sword', 'diamond_sword', 'iron_sword', 'stone_sword', 'wooden_sword'];

    let bestWeapon = null;
    let bestScore = -1;

    for (const item of items) {
      if (!item) continue;
      const index = priorities.indexOf(item.name);
      if (index !== -1) {
        const score = priorities.length - index;
        if (score > bestScore) {
          bestScore = score;
          bestWeapon = item;
        }
      }
    }

    if (!bestWeapon) return;

    const heldItem = this.bot.heldItem;
    if (!heldItem || heldItem.name !== bestWeapon.name) {
      try {
        await this.bot.equip(bestWeapon, 'hand');
        log.info(`Mengganti Sword: ${bestWeapon.name}`);
        if (this.chatQueue) this.chatQueue.send(`Mengganti Sword ke ${bestWeapon.name}`);
      } catch (_err) {
        log.warn(`Gagal equip weapon: ${_err.message}`);
      }
    }
  }

  /**
   * Buang semua item sampah yang ada di konfigurasi trashItems.
   */
  async dropTrash() {
    if (!this.bot.inventory) return;

    const trashNames = config.inventory.trashItems || [];
    if (trashNames.length === 0) return;

    const items = this.bot.inventory.items();
    let droppedCount = 0;

    for (const item of items) {
      if (trashNames.includes(item.name)) {
        try {
          await this.bot.tossStack(item);
          droppedCount += item.count;
          log.info(`Membuang ${item.name} (${item.count}x)`);
          await sleep(500);
        } catch (err) {
          log.warn(`Gagal membuang ${item.name}: ${err.message}`);
        }
      }
    }

    if (droppedCount > 0 && this.chatQueue) {
      this.chatQueue.send(`Berhasil membuang ${droppedCount} item sampah.`);
    }
  }

  /**
   * Buang item spesifik (give to owner usually).
   * @param {string} itemName 
   */
  async dropItemByName(itemName) {
    if (!this.bot.inventory) return 0;
    
    const items = this.bot.inventory.items();
    const targets = items.filter(i => i.name === itemName);
    let count = 0;

    for (const item of targets) {
      try {
        await this.bot.tossStack(item);
        count += item.count;
        await sleep(400);
      } catch (err) {}
    }
    return count;
  }

  /**
   * Drop seluruh item inventory kecuali yang dilindungi.
   */
  async dropAll() {
    if (!this.bot.inventory) return 0;

    const protectedKeywords = config.inventory.protectedItems || ['sword', 'armor', 'food', 'totem', 'ender_pearl', 'diamond'];
    const items = this.bot.inventory.items();
    let count = 0;

    for (const item of items) {
      const isProtected = protectedKeywords.some(kw => item.name.toLowerCase().includes(kw.toLowerCase()));
      if (!isProtected) {
        try {
          await this.bot.tossStack(item);
          count += item.count;
          await sleep(400);
        } catch (err) {}
      }
    }
    return count;
  }

  /**
   * Analisis inventory
   */
  getSummary() {
    if (!this.bot.inventory) return null;

    const items = this.bot.inventory.items();
    let pearlCount = 0;
    let foodCount = 0;
    let swordCount = 0;

    for (const item of items) {
      if (item.name === 'ender_pearl') pearlCount += item.count;
      else if (item.foodPoints) foodCount += item.count;
      else if (item.name.includes('sword')) swordCount += item.count;
    }

    const emptySlots = 36 - items.length; // Perkiraan kasaran slot kosong

    return {
      pearlCount,
      foodCount,
      swordCount,
      emptySlots
    };
  }
}

module.exports = InventoryManager;
