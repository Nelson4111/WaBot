'use strict';

const { createModuleLogger } = require('../../utils/logger');
const config = require('../../config');
const { formatMobName } = require('../../utils/formatter');

const log = createModuleLogger('GuardMode');

/** Set nama mob hostile yang dikenali */
const HOSTILE_MOB_SET = new Set(config.guard.hostileMobs);

/**
 * GuardMode memindai entity dalam radius tertentu dan menyerang
 * mob hostile menggunakan plugin mineflayer-pvp.
 *
 * Fitur:
 * - Scan entity setiap N ms (configurable)
 * - Filter hanya mob hostile dari daftar di config.json
 * - Toggle on/off via command !guard
 * - Stop otomatis saat bot mati
 */
class GuardMode {
  /**
   * @param {import('mineflayer').Bot} bot
   * @param {import('./Pathfinder')} pathfinder
   */
  constructor(bot, pathfinder) {
    this.bot = bot;
    this.pathfinder = pathfinder;
    this.isActive = false;
    this._scanInterval = null;
  }

  /**
   * Aktifkan guard mode.
   *
   * @returns {void}
   */
  start() {
    if (this.isActive) {
      log.warn('Guard mode sudah aktif');
      return;
    }

    if (!this.bot.pvp) {
      log.warn('Plugin mineflayer-pvp tidak tersedia. Guard mode tidak bisa diaktifkan.');
      return;
    }

    this.isActive = true;
    this._startScan();
    log.success(`Guard mode aktif — radius: ${config.guard.radius} blok`);
  }

  /**
   * Nonaktifkan guard mode.
   *
   * @returns {void}
   */
  stop() {
    if (!this.isActive) return;

    this.isActive = false;
    this._stopScan();

    // Hentikan serangan yang sedang berlangsung
    if (this.bot.pvp) {
      this.bot.pvp.stop();
    }

    log.info('Guard mode nonaktif');
  }

  /**
   * Toggle guard mode.
   *
   * @returns {boolean} Status baru (true = aktif)
   */
  toggle() {
    if (this.isActive) {
      this.stop();
    } else {
      this.start();
    }
    return this.isActive;
  }

  /**
   * Mulai scan periodik untuk mencari mob hostile.
   *
   * @private
   */
  _startScan() {
    this._scanInterval = setInterval(() => {
      this._scanAndAttack();
    }, config.guard.attackInterval);
  }

  /**
   * Hentikan scan periodik.
   *
   * @private
   */
  _stopScan() {
    if (this._scanInterval) {
      clearInterval(this._scanInterval);
      this._scanInterval = null;
    }
  }

  /**
   * Scan entity di sekitar bot dan serang mob hostile terdekat.
   *
   * @private
   */
  async _scanAndAttack() {
    if (!this.isActive || !this.bot.entity) return;

    const target = this._findNearestHostile();

    if (target) {
      // 1. Auto equip pedang terbaik jika belum dipegang
      await this._equipBestWeapon().catch(() => {});

      const dist = target.position ? target.position.distanceTo(this.bot.entity.position) : 99;

      // 2. Jika target berada dalam jangkauan dekat (<= 4.5 block, misal di mob grinder), serang langsung!
      if (dist <= 4.5) {
        try {
          this.bot.attack(target);
          log.debug(`Memukul ${formatMobName(target.name)} di jarak dekat (${Math.round(dist * 10) / 10}m)`);
        } catch (_err) {
          // Silent
        }
      } else if (this.bot.pvp && !this.bot.pvp.target) {
        log.debug(`Menyerang ${formatMobName(target.name)} (${target.id}) via PVP pathfinding`);
        this.bot.pvp.attack(target);
      }
    }
  }

  /**
   * Cari pedang/senjata terbaik di inventory dan equip ke tangan utama.
   *
   * @private
   */
  async _equipBestWeapon() {
    if (!this.bot.inventory) return;

    const items = this.bot.inventory.items();
    const weaponKeywords = ['sword', 'axe'];

    const weapons = items.filter((item) =>
      item && weaponKeywords.some((kw) => item.name.toLowerCase().includes(kw))
    );

    if (weapons.length === 0) return;

    const getScore = (name) => {
      const n = name.toLowerCase();
      if (n.includes('netherite')) return 6;
      if (n.includes('diamond')) return 5;
      if (n.includes('iron')) return 4;
      if (n.includes('stone')) return 3;
      if (n.includes('golden')) return 2;
      if (n.includes('wooden')) return 1;
      return 0;
    };

    weapons.sort((a, b) => getScore(b.name) - getScore(a.name));
    const bestWeapon = weapons[0];

    const heldItem = this.bot.heldItem;
    if (!heldItem || heldItem.name !== bestWeapon.name) {
      try {
        await this.bot.equip(bestWeapon, 'hand');
        log.info(`Equip senjata: ${bestWeapon.name}`);
      } catch (_err) {
        // Silent
      }
    }
  }

  /**
   * Temukan mob hostile terdekat dalam radius yang dikonfigurasi.
   *
   * @returns {import('prismarine-entity').Entity|null}
   * @private
   */
  _findNearestHostile() {
    const entities = Object.values(this.bot.entities);
    let nearest = null;
    let nearestDistance = config.guard.radius;

    for (const entity of entities) {
      if (!entity || !entity.position) continue;
      // Filter tipe mob
      if (entity.type !== 'mob') continue;

      const mobName = (entity.name || entity.displayName || '').toLowerCase();
      const isHostile = HOSTILE_MOB_SET.has(mobName) || mobName.includes('enderman') || mobName.includes('zombie') || mobName.includes('skeleton');

      if (!isHostile) continue;
      // Skip entitas yang mati (health <= 0 atau metadata death)
      if (entity.metadata?.[8] === 1 || entity.health <= 0) continue;

      const distance = entity.position.distanceTo(this.bot.entity.position);
      if (distance < nearestDistance) {
        nearestDistance = distance;
        nearest = entity;
      }
    }

    return nearest;
  }
}

module.exports = GuardMode;
