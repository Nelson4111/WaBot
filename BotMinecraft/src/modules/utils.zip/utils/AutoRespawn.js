'use strict';

const { createModuleLogger } = require('../../utils/logger');
const { sleep } = require('../../utils/retry');

const log = createModuleLogger('AutoRespawn');

/** Delay sebelum respawn (ms) — cukup waktu untuk melihat death screen */
const RESPAWN_DELAY_MS = 2000;

/** Delay sebelum mulai aktivitas normal lagi setelah respawn (ms) */
const POST_RESPAWN_DELAY_MS = 3000;

/**
 * AutoRespawn secara otomatis me-respawn bot setelah mati.
 * Setelah respawn, memberikan delay singkat sebelum bot melanjutkan aktivitas.
 */
class AutoRespawn {
  /**
   * @param {import('mineflayer').Bot} bot
   */
  constructor(bot) {
    this.bot = bot;
    this.isActive = false;
    this._deathListener = null;
  }

  /**
   * Aktifkan auto-respawn.
   *
   * @returns {void}
   */
  start() {
    this._deathListener = async () => {
      log.warn(`Bot mati. Respawn dalam ${RESPAWN_DELAY_MS / 1000}s...`);
      await sleep(RESPAWN_DELAY_MS);

      try {
        this.bot.respawn();
        log.success('Bot berhasil respawn');
        await sleep(POST_RESPAWN_DELAY_MS);
        log.info('Bot siap kembali beraktivitas');
      } catch (err) {
        log.error(`Gagal respawn: ${err.message}`);
      }
    };

    this.bot.on('death', this._deathListener);
    this.isActive = true;
    log.info('AutoRespawn aktif');
  }

  /**
   * Hentikan auto-respawn.
   *
   * @returns {void}
   */
  stop() {
    if (this._deathListener) {
      this.bot.removeListener('death', this._deathListener);
      this._deathListener = null;
    }
    this.isActive = false;
    log.info('AutoRespawn dihentikan');
  }
}

module.exports = AutoRespawn;
